defmodule VocialWeb.PageViewTest do
  use VocialWeb.ConnCase, async: true
end
