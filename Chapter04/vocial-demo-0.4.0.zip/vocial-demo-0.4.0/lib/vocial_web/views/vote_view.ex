defmodule VocialWeb.VoteView do
  use VocialWeb, :view
end
