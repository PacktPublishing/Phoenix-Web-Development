defmodule VocialWeb.LayoutView do
  use VocialWeb, :view
end
