defmodule VocialWeb.SessionView do
  use VocialWeb, :view
end
