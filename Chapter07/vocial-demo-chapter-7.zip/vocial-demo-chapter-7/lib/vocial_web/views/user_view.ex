defmodule VocialWeb.UserView do
  use VocialWeb, :view
end
