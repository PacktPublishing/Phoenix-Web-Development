// Import the default Phoenix HTML libraries
import 'phoenix_html';
// Import the User Socket code to enable websockets
import socket from './socket';
