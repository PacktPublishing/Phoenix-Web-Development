defmodule VocialWeb.LayoutViewTest do
  use VocialWeb.ConnCase, async: true
end
