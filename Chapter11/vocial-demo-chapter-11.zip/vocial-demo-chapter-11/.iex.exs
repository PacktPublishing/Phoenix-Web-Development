import Ecto.Query
alias Vocial.Repo

alias Vocial.Votes
alias Vocial.Votes.Poll
alias Vocial.Votes.Option
alias Vocial.Votes.Image
alias Vocial.Votes.VoteRecord
alias Vocial.Votes.Message

alias Vocial.Accounts
alias Vocial.Accounts.User