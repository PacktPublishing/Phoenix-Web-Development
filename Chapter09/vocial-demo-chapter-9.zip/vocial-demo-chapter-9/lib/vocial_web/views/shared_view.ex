defmodule VocialWeb.SharedView do
  use VocialWeb, :view
end