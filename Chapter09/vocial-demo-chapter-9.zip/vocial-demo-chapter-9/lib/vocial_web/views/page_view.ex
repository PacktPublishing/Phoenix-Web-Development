defmodule VocialWeb.PageView do
  use VocialWeb, :view
end
