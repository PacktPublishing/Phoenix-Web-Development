ExUnit.start()

Ecto.Adapters.SQL.Sandbox.mode(Vocial.Repo, :manual)

